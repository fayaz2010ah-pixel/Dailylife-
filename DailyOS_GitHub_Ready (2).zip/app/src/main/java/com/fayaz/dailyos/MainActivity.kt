package com.fayaz.dailyos

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var progress: TextView
    private var done = 0
    private var total = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUI()
    }

    private fun buildUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.rgb(17,19,24))
        }

        val title = TextView(this).apply {
            text = "DailyOS"
            textSize = 32f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "Your day. Your habits. Your progress."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, 4, 0, 18)
        }
        root.addView(sub)

        progress = TextView(this).apply {
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(32,35,43))
        }
        root.addView(progress)

        val add = Button(this).apply {
            text = "＋  Add task"
            setOnClickListener { showAddDialog() }
        }
        root.addView(add)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 0)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "Study  •  Workout  •  Learn  •  Reflect"
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
            setPadding(0, 12, 0, 4)
        }
        root.addView(footer)

        setContentView(root)
        addTask("Study — Class 11", false)
        addTask("Workout", false)
        addTask("Learn something new", false)
        addTask("Read / revise", false)
        addTask("Daily reflection", false)
        updateProgress()
    }

    private fun addTask(name: String, checked: Boolean) {
        total++
        val box = CheckBox(this).apply {
            text = name
            textSize = 17f
            setTextColor(Color.WHITE)
            isChecked = checked
            setPadding(10, 12, 10, 12)
            setOnCheckedChangeListener { _, value ->
                done += if (value) 1 else -1
                updateProgress()
            }
        }
        list.addView(box)
        if (checked) done++
    }

    private fun updateProgress() {
        progress.text = "Today: $done / $total completed"
    }

    private fun showAddDialog() {
        val input = EditText(this).apply { hint = "Task name" }
        AlertDialog.Builder(this)
            .setTitle("Add a task")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Add") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) addTask(text, false)
                updateProgress()
            }.show()
    }
}
