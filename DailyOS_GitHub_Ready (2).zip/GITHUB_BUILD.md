# DailyOS

GitHub-ready Android project.

## Build the APK from your phone

1. Create a GitHub repository.
2. Upload all files in this project to the repository.
3. Open **Actions**.
4. Select **Build DailyOS APK**.
5. Tap **Run workflow**.
6. When it finishes, open the workflow run.
7. Download the **DailyOS-APK** artifact.
8. Extract it and install `app-debug.apk` on your Android phone.

The app ID is `com.fayaz.dailyos`.
