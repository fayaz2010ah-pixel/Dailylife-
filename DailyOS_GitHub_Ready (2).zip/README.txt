DailyOS
-------
A simple Android productivity app.

Features in v1:
- Daily task checklist
- Study, workout, learning and reflection tasks
- Add your own tasks
- Daily completion counter
- Dark premium-style interface

Build:
Open this project in Android Studio and build the debug APK.
Application ID: com.fayaz.dailyos
Minimum Android: 6.0 (API 23)
Target Android: API 35
